const express = require('express');
const router = express.Router();
const Blog = require('../models/blog');

// INDEX - Show all blogs
router.get('/', async (req, res) => {
    const blogs = await Blog.find({});
    res.render('index', { blogs });
});

// NEW - Show form to create new blog
router.get('/new', (req, res) => {
    res.render('new');
});

// CREATE - Add new blog to DB
router.post('/', async (req, res) => {
    await Blog.create(req.body.blog);
    res.redirect('/blogs');
});

// SHOW - Shows more info about one blog
router.get('/:id', async (req, res) => {
    const blog = await Blog.findById(req.params.id);
    res.render('show', { blog });
});

// EDIT - Show edit form for one blog
router.get('/:id/edit', async (req, res) => {
    const blog = await Blog.findById(req.params.id);
    res.render('edit', { blog });
});

// UPDATE - Update a particular blog
router.put('/:id', async (req, res) => {
    await Blog.findByIdAndUpdate(req.params.id, req.body.blog);
    res.redirect(`/blogs/${req.params.id}`);
});

// DELETE - Delete a particular blog
router.delete('/:id', async (req, res) => {
    await Blog.findByIdAndRemove(req.params.id);
    res.redirect('/blogs');
});

module.exports = router;
